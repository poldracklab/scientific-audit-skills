#include<stdio.h>
#include<conio.h>
#include<math.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 		   1
#define FALSE		   0
#define SUBS		  15
#define BLOCKS		   3
#define TRIALS		 100
#define STRLEN		 100
#define DIGITS		   5
#define NUM			   9

#define _MAC_
//#define _PC_

#define S1REPEAT 0
#define S2REPEAT 1
#define S1U 2
#define S2U 3
#define S3S 4
#define S3D 5
#define REPEAT 1
#define UNIQUE 2
#define SAMENEW 3
#define DIFFNEW 4
#define SAMEDIST 6
#define NEWDIST 7

FILE *GetFilePtr(char *InFile, int OpenMode);
FILE *GetData(FILE *in, char *InpStr, int sub);
void ErrType(int SubNum, int LibOrCon);
void 	flush_kbd(void);

struct ErrorStrings
{
  char 	string[5];		// to-be-entered string
  int	type;			// 0 = repeat, 2 = unique
  char  choice[5];		// string subject entered

} data[SUBS][BLOCKS][TRIALS];

//legal transition set one

int	One[NUM][NUM] = { 	0,1,0,1,0,0,0,1,1,  	/* 1 -> 2,4,8,9 */
						0,0,1,0,1,1,1,0,0,      /* 2 -> 3,5,6,7 */
						1,0,0,0,0,0,1,1,1,      /* 3 -> 1,7,8,9 */
						0,1,1,0,1,1,0,0,0,      /* 4 -> 2,3,5,6 */
						0,1,0,0,0,1,0,1,1,      /* 5 -> 2,6,8,9 */
						1,0,1,0,1,0,0,0,1,      /* 6 -> 1,3,5,9 */
						1,0,1,1,0,0,0,1,0,      /* 7 -> 1,3,4,8 */
						1,0,0,1,0,1,1,0,0,      /* 8 -> 1,4,6,7 */
						0,1,0,1,1,0,1,0,0 };    /* 9 -> 2,4,5,7 */

//legal transition set two

int	Two[NUM][NUM] = {   0,0,1,0,1,1,1,0,0,      /* 1 -> 3,5,6,7 */
						1,0,0,1,0,0,0,1,1,      /* 2 -> 1,4,8,9 */
						0,1,0,1,1,1,0,0,0,      /* 3 -> 2,4,5,6 */
						1,0,0,0,0,0,1,1,1,      /* 4 -> 1,7,8,9 */
						1,0,1,1,0,0,1,0,0,      /* 5 -> 1,3,4,7 */
						0,1,0,1,0,0,1,1,0,      /* 6 -> 2,4,7,8 */
						0,1,0,0,1,1,0,0,1,      /* 7 -> 2,5,6,9 */
						0,1,1,0,1,0,0,0,1,      /* 8 -> 2,3,5,9 */
						1,0,1,0,0,1,0,1,0 };    /* 9 -> 1,3,6,8 */

int KeyLib[NUM][NUM] = {	1,1,0,1,1,0,0,0,0,   	/* 1 -> 1,2,4,5 */
							1,1,1,1,1,1,0,0,0,      /* 2 -> 1,2,3,4,5,6 */
							0,1,1,0,1,1,0,0,0,      /* 3 -> 2,3,5,6 */
							1,1,0,1,1,0,1,1,0,		/* 4 -> 1,2,4,5,7,8 */
							1,1,1,1,1,1,1,1,1,      /* 5 -> 1-9 */
							0,1,1,0,1,1,0,1,1,		/* 6 -> 2,3,5,6,8,9 */
							0,0,0,1,1,0,1,1,0,		/* 7 -> 4,5,7,8 */
							0,0,0,1,1,1,1,1,1,      /* 8 -> 4,5,6,7,8,9 */
							0,0,0,0,1,1,0,1,1 };	/* 9 -> 5,6,8,9 */

/*int KeyCon[NUM][NUM] = {	1,1,0,1,1,0,0,0,0,   	 1 -> 1,2,4,5 */
/*							1,1,1,0,1,0,0,0,0,       2 -> 1,2,3,5 */
/*							0,1,1,0,1,1,0,0,0,       3 -> 2,3,5,6 */
/*							1,1,0,0,1,0,1,0,0,		 4 -> 1,2,5,7 */
/*							0,1,0,1,1,1,0,1,0,       5 -> 2,4,5,6,8 */
/*							0,0,1,0,1,1,0,0,1,		 6 -> 3,5,6,9 */
/*							0,0,0,1,1,0,1,1,0,		 7 -> 4,5,7,8 */
/*							0,0,0,0,1,0,1,1,1,       8 -> 5,7,8,9 */
/*							0,0,0,0,1,1,0,1,1 };	 9 -> 5,6,8,9 */

int KeyCon[NUM][NUM] = {	0,1,0,1,0,0,0,0,0,   	/* 1 -> 2,4 */
							1,0,1,1,1,0,0,0,0,      /* 2 -> 1,3,4,5 */
							0,1,0,0,0,1,0,0,0,      /* 3 -> 2,6 */
							1,1,0,0,1,1,1,0,0,		/* 4 -> 1,2,5,6,7 */
							0,1,0,0,0,1,0,1,0,      /* 5 -> 2,6,8 */
							0,0,1,0,1,0,0,0,1,		/* 6 -> 3,5,9 */
							0,0,0,1,0,0,0,1,0,		/* 7 -> 4,8 */
							0,0,0,0,1,0,1,0,1,      /* 8 -> 5,7,9 */
							0,0,0,0,0,1,0,1,0 };	/* 9 -> 6,8 */

void
main(void)
{
	int 	i,j,k,l,Num1,Num2,Num3,Ctr;
	char	FileName[15] = {"erranal1.out"};
	FILE	*ptr;
	char	InpStr[STRLEN];

	ptr=GetFilePtr(FileName,1);

	for(i=0;i<SUBS;i++)
		ptr=GetData(ptr, InpStr, i);
	fclose(ptr);
	for(i=0;i<SUBS;i++)
		ErrType(i,1);       // 0=LibKeyBoardArray, 1=ConKeyBoardArray
	printf("\n\nDONE!");
}

void
ErrType(int SubNum, int LibOrCon)
{
	int		transxdig[BLOCKS][NUM][NUM]; //stimulus digit, subject's entry
	float		leg_err[BLOCKS],tot_err[BLOCKS],temp=0.0;
	float		leg_not_key_err[BLOCKS], key_err[BLOCKS];
	float		sym_err[BLOCKS];
	int		fr_dig[NUM],to_dig[NUM],fr_to_trans[NUM*NUM];
	int		from_to[NUM][NUM],fr_to_size[NUM*NUM];
	int		num_err[DIGITS],stim_pos[BLOCKS][DIGITS];
	int 	a,b,c,d,i,j,l,x,z,trials,stim[DIGITS],entry[DIGITS];
	int		ctr;
	char	OutFileLib[10]={"elib1.dat"};
	char	OutFileCon[10]={"econ1.dat"};
	FILE 	*out;

	for(i=0;i<DIGITS;i++)
		num_err[i]=0;

	for(i=0;i<NUM;i++) {
		fr_dig[i]=0;
		to_dig[i]=0;
	}
	for(z=0;z<BLOCKS;z++){
		for(i=0;i<DIGITS;i++)
			stim_pos[z][i]=0;
		leg_err[z]=tot_err[z]=0;
		key_err[z]=leg_not_key_err[z]=0;
		sym_err[z]=0;
		for(i=0;i<NUM;i++)
			for(j=0;j<NUM;j++)
				transxdig[z][i][j]=0;
	}

	for(i=0;i<BLOCKS;i++) {
		for(j=0;j<TRIALS;j++) {
			for(l=0;l<DIGITS;l++) {
				stim[l]=0;
				entry[l]=0;
			}

			for(a=0;a<DIGITS;a++) {
				if(data[SubNum][i][j].string[a]!=data[SubNum][i][j].choice[a]) {
					for(b=1;b<NUM+1;b++)
						if(b==(data[SubNum][i][j].string[a]-48))
							stim[a]=b;
					for(c=1;c<NUM+1;c++)
						if(c==(data[SubNum][i][j].choice[a]-48))
							entry[a]=c;
				}
			}

			for(d=0;d<DIGITS;d++) {
				if(stim[d]) {
					transxdig[i][stim[d]-1][entry[d]-1]++;
					switch(LibOrCon)
					{
						case 0: if(d && (KeyLib[data[SubNum][i][j].choice[d-1]-49][data[SubNum][i][j].choice[d]-49]) )
							key_err[i]++;
							break;
						case 1: if(d && (KeyCon[data[SubNum][i][j].choice[d-1]-49][data[SubNum][i][j].choice[d]-49]) )
							key_err[i]++;
							break;
					}
					if( (((SubNum+2)%2)==0) && d) {
						if(One[data[SubNum][i][j].choice[d-1]-49][data[SubNum][i][j].choice[d]-49]) {
							leg_err[i]++;
							switch(LibOrCon)
							{
								case 0: if(!KeyLib[data[SubNum][i][j].choice[d-1]-49][data[SubNum][i][j].choice[d]-49])
									leg_not_key_err[i]++;
									break;
								case 1: if(!KeyCon[data[SubNum][i][j].choice[d-1]-49][data[SubNum][i][j].choice[d]-49])
									leg_not_key_err[i]++;
									break;
							}
						}
					}
					else if( (((SubNum+2)%2)!=0) && d) {
						if(Two[data[SubNum][i][j].choice[d-1]-49][data[SubNum][i][j].choice[d]-49]) {
							leg_err[i]++;
							switch(LibOrCon)
							{
								case 0: if(!KeyLib[data[SubNum][i][j].choice[d-1]-49][data[SubNum][i][j].choice[d]-49])
									leg_not_key_err[i]++;
									break;
								case 1: if(!KeyCon[data[SubNum][i][j].choice[d-1]-49][data[SubNum][i][j].choice[d]-49])
									leg_not_key_err[i]++;
									break;
							}
						}
					}
					stim_pos[i][d]++;  /* at what pos. did error occur ? */
					tot_err[i]++;      /* total number of errors */
					if( (stim[d]==entry[d+1]) && (entry[d]==stim[d+1]) )
						sym_err[i]++;  /* symmetric errors */
				}
			}
			ctr=0;
			for(d=0;d<DIGITS;d++)
				if(stim[d])
					ctr++;
			switch(ctr){
				case 1: num_err[0]++; break;
				case 2: num_err[1]++; break;
				case 3: num_err[2]++; break;
				case 4: num_err[3]++; break;
				case 5: num_err[4]++; break;
			}
		}
	}
	transxdig[0][8][8]=0;
	transxdig[1][8][8]=0;		 /* reset 0s entered by subjects, */
	//printf("DONE!");                       /* which were not allowed and */
											 /* get counted in the wrong */
											 /* place in the array */

	for(i=0;i<NUM;i++) {                     /* from */
		fr_dig[i]=to_dig[i]=0;
		for(j=0;j<NUM;j++) {                 /* to */
			for(z=0;z<2;z++) {
				fr_dig[i]+=transxdig[z][i][j];    /* sum across to  */
				to_dig[i]+=transxdig[z][j][i];    /* sum acros from */
			}
		}
	}
	for(i=0;i<NUM;i++) {
		for(j=0;j<NUM;j++) {
			from_to[i][j]=0;
			for(z=0;z<2;z++)
				from_to[i][j]+=transxdig[z][i][j]; // collapse across blocks
		}
	}

	out = GetFilePtr((!LibOrCon?OutFileLib:OutFileCon),2);

	//if(!SubNum)
	//	fprintf(out,"DET EXPT. 1 ERROR DATA ANALYSIS 3/14/95 (N=15)\n");

	for(i=0,temp=0;i<3;i++)
		temp+=tot_err[i];
	fprintf(out,"%5.0f",temp);
	for(i=0;i<3;i++)
		fprintf(out,"\t%5.2f",(tot_err[i]/temp)*100);

	fprintf(out,"\t%5.0f\t%5.2f",(leg_err[0]+leg_err[1]+leg_err[2]),
		((leg_err[0]+leg_err[1]+leg_err[2])/temp)*100);
	for(i=0;i<3;i++)
		fprintf(out,"\t%5.2f",(leg_err[i]/tot_err[i])*100);

	fprintf(out,"\t%5.0f\t%5.2f",(key_err[0]+key_err[1]+key_err[2]),
		((key_err[0]+key_err[1]+key_err[2])/temp)*100);
	for(i=0;i<3;i++)
		fprintf(out,"\t%5.2f",(key_err[i]/tot_err[i])*100);

	fprintf(out,"\t%5.0f\t%5.2f",(leg_not_key_err[0]+leg_not_key_err[1]+leg_not_key_err[2]),
		((leg_not_key_err[0]+leg_not_key_err[1]+leg_not_key_err[2])/temp)*100);
	for(i=0;i<3;i++)
		fprintf(out,"\t%5.2f",(leg_not_key_err[i]/tot_err[i])*100);

	fprintf(out,"\t%5.0f\t%5.2f",(sym_err[0]+sym_err[1]+sym_err[2]),
		((sym_err[0]+sym_err[1]+sym_err[2])/temp)*100);
	for(i=0;i<3;i++)
		fprintf(out,"\t%5.2f",(sym_err[i]/tot_err[i])*100);

	//for(i=0;i<DIGITS;i++)
	//	fprintf(out,"%5d\t",num_err[i]);

	for(z=0;z<BLOCKS;z++)
		for(i=0;i<DIGITS;i++)
			fprintf(out,"\t%5d",stim_pos[z][i]);

	//fprintf(out,"\n\nSUPPOSED-TO TO ENTERED ERROR MATRIX:\n");
	//for(i=0;i<NUM;i++) {
	//	fprintf(out,"\n");
	//	for(j=0;j<NUM;j++)
	//		fprintf(out,"%5d\t",from_to[i][j]);
	//}
	//fprintf(out,"\n\nERRORS MADE FROM DIGIT N:\n\n");
	for(i=0;i<NUM;i++)
		fprintf(out,"\t%5d",fr_dig[i]);
	//fprintf(out,"\n\nERRORS MADE TO DIGIT N:\n\n");
	for(i=0;i<NUM;i++)
		fprintf(out,"\t%5d",to_dig[i]);
	fprintf(out,"\n");
	//fprintf(out,"\n\nSESSION ONE SUPPOSED-TO TO ENTERED ERROR MATRIX:\n\n");
	//for(i=0;i<NUM;i++) {
	//	fprintf(out,"\n");
	//	for(j=0;j<NUM;j++)
	//		fprintf(out,"%5d\t",transxdig[0][i][j]);
	//}
	//fprintf(out,"\n\nSESSION TWO SUPPOSED-TO TO ENTERED ERROR MATRIX:\n\n");
	//for(i=0;i<NUM;i++) {
	//	fprintf(out,"\n");
	//	for(j=0;j<NUM;j++)
	//		fprintf(out,"%5d\t",transxdig[1][i][j]);
	//}
	//fprintf(out,"\n\nSESSION THREE SUPPOSED-TO To ENTERED ERROR MATRIX:\n\n");
	//for(i=0;i<NUM;i++) {
	//	fprintf(out,"\n");
	//	for(j=0;j<NUM;j++)
	//		fprintf(out,"%5d\t",transxdig[2][i][j]);
	//}
	fclose(out);
}


FILE
*GetFilePtr(char *InFile, int OpenMode)
{
	FILE 	*p;

	if( (p = fopen(InFile, ((OpenMode==1)?"rt":"a+"))) == NULL)
	{
		clrscr();
		fprintf(stderr, "ERROR OPENING %s\n", InFile);
		exit (1);
	}
	return(p);
}

FILE
*GetData(FILE *in, char *InpStr, int sub)
{
	int 	a,b,i,type,num1=0,num2=0,trials;
	char    choice[6],string[6];
	char	block2[8]={"Block 2"},block3[8]={"Block 3"},end[8]={"*******"};
	float	rt1,rt2,rt3,rt4,rt5,end_rt;
	char  	*begin;

	i=0; // block counter
	do{
		for(a=0;a<TRIALS;) {
			fgets(InpStr, STRLEN, in);
			for(b=0;b<10;b++)
				*(begin+b)=InpStr[b];
			*(begin+7)='\0';
			if( (InpStr[0]!='B') && (InpStr[0]!='S') && (InpStr[0]!='*') ){
				sscanf(InpStr, "%s\t%s\t%d",string,choice,&type);
					strcpy(data[sub][i][a].string,string);
					strcpy(data[sub][i][a].choice,choice);
					data[sub][i][a].type = type;
				a++;
			}
			else if(!strcmp(begin,block2)) {
				i=1; a=0; }
			else if(!strcmp(begin,block3)) {
				i=2; a=0; }
			else if(!strcmp(begin,end)) {
				i=3; a=101; }
		}
	} while(i<3);
	return(in);
}

void flush_kbd(void)
{
	#ifdef _PC_
   		*(char far *) 0x0000041AL = *(char far *) 0x0000041CL;
   	#endif
   	#ifdef _MAC_
   		FlushEvents(everyEvent, 0L);
   	#endif
}

