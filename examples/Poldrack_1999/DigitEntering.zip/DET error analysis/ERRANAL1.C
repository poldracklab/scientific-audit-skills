#include<stdio.h>
#include<conio.h>
#include<math.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 		   1
#define FALSE		   0
#define SUBS		  15
#define BLOCKS		   3
#define TRIALS		 576
#define STRLEN		 100
#define DIGITS		   5
#define NUM 		   9

#define S1REPEAT 0
#define S2REPEAT 1
#define S1U 2
#define S2U 3
#define S3S 4
#define S3D 5
#define REPEAT 1
#define UNIQUE 2
#define SAMENEW 3
#define DIFFNEW 4
#define SAMEDIST 6
#define NEWDIST 7

FILE *GetFilePtr(char *InFile);
void GetData(FILE *in, int block, char *InpStr);
void CalcErrRate(char *sub);
void LegalTrans(int sub);

struct InputStrings
{
  char 	string[5];		// to-be-entered string
  float	rt[5];   		// individual digit (1-5) reaction times
  int	type;			// 0 = repeat, 2 = unique
  char  choice[5];		// string subject entered
  int	dash;			// dash trial flag

} data[BLOCKS][288];

struct LegalTransitions
{
  int 	fr_to[NUM][NUM];

} tran[SUBS];

float	NumMissed[BLOCKS];

void
main(void)
{
	int 	a,b,c,d,z,i,j,k,l,Num1,Num2,Num3,Ctr;
	char	FileName[10] = {"subxx.ox"};
	FILE	*ptr;
	char	sub[SUBS][4] = { "01","02","03","04","05","06","07","08",
							 "09","10","11","12","13","14","16"};

	char 	ext[3] = { '1','2','3' };
	char	InpStr[STRLEN];
	float	*NumCor;

	for(i=0;i<SUBS;i++)
	{
		sub[i][3]='\0';
		for(k=0;k<2;k++)
			FileName[k+3] = sub[i][k];

		for(j=0;j<BLOCKS;j++) {
			NumMissed[j]=0.0;
			FileName[7]=ext[j];
			ptr=GetFilePtr(FileName);
			GetData(ptr, j, InpStr);
		}
		//LegalTrans(i);
		//printf("SUB: %s", sub[i]);
		//printf("\n\n");
		//for(a=0;a<NUM;a++) {
		//	for(b=0;b<NUM;b++)
		//		printf("%3d", tran[i].fr_to[a][b]);
		//	printf("\n");
		//}
		//printf("\n\n");
		CalcErrRate(sub[i]);
	}
	// printf("\nDONE!\n");
}

void
LegalTrans(int sub)
{
	int	a,b,c,i,j,z,from=0,to=0;

	for(i=0;i<NUM;i++)
		for(j=0;j<NUM;j++)
			tran[sub].fr_to[i][j] = FALSE;

	for(i=0;i<BLOCKS-2;i++)
		for(j=0;j<TRIALS;j++)
			for(a=0;a<DIGITS-1;a++)
				tran[sub].fr_to[data[i][j].string[a]-49][data[i][j].string[a+1]-49] = TRUE;
}


void
CalcErrRate(char *sub)
{
	int 	a,j,trials;
	float	NumCor[BLOCKS]= { 0.0,0.0,0.0 };
	FILE	*out;
	char	OutFile[13] = { "erranal1.out" };

	if ((out = fopen(OutFile, "a+")) == NULL)
	{
		fprintf(stderr, "\n\nERROR OPENING %s", OutFile);
		exit(1);
	}

	fprintf(out, "Sub %s:", sub);
	for(j=0;j<BLOCKS;j++)
		fprintf(out, "\t%5.2f", ((576.0-NumMissed[j])/576.0)*100 );
	fprintf(out,"\n");
	for(j=0;j<BLOCKS;j++) {
		fprintf(out, "Block %d:\n",j+1);
		//FIX THIS FOR STATEMENT
		for(a=0;a<NumMissed[j];a++) {
			if(!data[j][a].dash)
				fprintf(out, "%.5s\t%.5s\t%d\t%5.0f\t%5.0f\t%5.0f\t%5.0f\t%5.0f\n",
					data[j][a].string,data[j][a].choice,data[j][a].type,
					data[j][a].rt[0],data[j][a].rt[1],data[j][a].rt[2],
					data[j][a].rt[3],data[j][a].rt[4]);
		}
	}
	fprintf(out, "*******\n");
	fclose(out);

	if ((out = fopen("expt1acc.dat", "a+")) == NULL)
	{
		fprintf(stderr, "\n\nERROR OPENING %s", "expt1acc.dat");
		exit(1);
	}
	for(j=0;j<BLOCKS;j++)
		fprintf(out, "%5.2f\t", ((576.0-NumMissed[j])/576.0)*100 );
	fprintf(out,"\n");
	fclose(out);
}

FILE
*GetFilePtr(char *InFile)
{
	FILE 	*p;

	if( (p = fopen(InFile, "rt")) == NULL)
	{
		clrscr();
		fprintf(stderr, "ERROR OPENING %s\n", InFile);
		exit (1);
	}
	return(p);
}

void
GetData(FILE *in, int block, char *InpStr)
{
	int 	a,b,i,z,end,num,type,trials;
	char    dig1,dig2,dig3,dig4,dig5,dig[6],label[6];
	float	rt1,rt2,rt3,rt4,rt5,end_rt;

	switch(block) {
		case 0: case 1: case 2: trials=TRIALS; break;
		//case 2: trials=192; break;
	}

	for(z=0,a=0;z<trials;z++) {
		fgets(InpStr, STRLEN, in);
		sscanf(InpStr, "%s\t%d\t%f\t%c\t%f\t%c\t%f\t%c\t%f\t%c\t%f\t%c\t%f\%d\t\n",
			label,&type,&rt1,&dig1,&rt2,&dig2,&rt3,&dig3,&rt4,&dig4,&rt5,&dig5,&end_rt,&end);
		strcpy(data[block][a].string,label);
		dig[0] = dig1;
		dig[1] = dig2;
		dig[2] = dig3;
		dig[3] = dig4;
		dig[4] = dig5;
		dig[5] = '\0';
		strcpy(data[block][a].choice,dig);
		if(strcmp(data[block][a].string,data[block][a].choice))
		{
			data[block][a].rt[0] = rt1;
			data[block][a].rt[1] = rt2;
			data[block][a].rt[2] = rt3;
			data[block][a].rt[3] = rt4;
			data[block][a].rt[4] = rt5;
			data[block][a].type = type;
			for(i=0;i<DIGITS;i++)
				if(data[block][a].choice[i]=='-')
					data[block][a].dash=TRUE;
			a++;
			NumMissed[block]++;
		}
	}

	fclose(in);
}

